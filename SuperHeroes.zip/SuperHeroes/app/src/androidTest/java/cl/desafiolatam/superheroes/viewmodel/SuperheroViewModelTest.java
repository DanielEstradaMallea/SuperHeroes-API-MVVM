package cl.desafiolatam.superheroes.viewmodel;


import static org.mockito.Mockito.verify;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.lifecycle.Observer;


import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;


import cl.desafiolatam.superheroes.model.superhero.SuperheroItem;

@RunWith(MockitoJUnitRunner.class)
public class SuperheroViewModelTest {
    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();

    @Mock
    private Observer<List<SuperheroItem>> heroListObserver;

    @Mock
    private Observer<SuperheroItem> heroObserver;

    private SuperheroViewModel viewModel;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        viewModel = new SuperheroViewModel();
        viewModel.getHeroesList().observeForever(heroListObserver);
        viewModel.getHeroDetails().observeForever(heroObserver);
    }

    @Test
    public void test_llamar_apiHero() throws InterruptedException {
         viewModel.callApiHeroes();
        Thread.sleep(3000);
        List<SuperheroItem> h = viewModel.getHeroesList().getValue();
        verify(heroListObserver).onChanged(viewModel.getHeroesList().getValue());

    }

    @Test
    public void obtenerDetalleTest() throws InterruptedException {

        viewModel.callApiHeroes();
        Thread.sleep(4000);
        List<SuperheroItem> list = viewModel.getHeroesList().getValue();
        viewModel.getHero(list.get(1));
        verify(heroObserver).onChanged(viewModel.getHeroDetails().getValue());

    }
}