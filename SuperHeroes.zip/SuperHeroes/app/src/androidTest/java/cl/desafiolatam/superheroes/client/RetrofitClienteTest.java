package cl.desafiolatam.superheroes.client;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.google.common.truth.Truth;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.util.List;

import cl.desafiolatam.superheroes.LectorJson;
import cl.desafiolatam.superheroes.model.superhero.SuperheroItem;
import cl.desafiolatam.superheroes.service.SuperheroAPI;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;

@RunWith(AndroidJUnit4.class)
public class RetrofitClienteTest {

    private MockWebServer server;
    private String url = "http://localhost:8080/api/";
    private String body = LectorJson.lector("heroDummie.json");

    @Before
    public void setUp() throws Exception {
        server = new MockWebServer();
        server.start(8080);
        server.enqueue(new MockResponse().setResponseCode(200).setBody(body));
        server.url("all.json");
    }

    @After
    public void tearDown() throws Exception{
        server.shutdown();
    }

    @Test
    public void test_CallSuccess() {

            SuperheroAPI service = RetrofitCliente.getInstance(url);
            try{
                List<SuperheroItem> lista = service.CallToHeroes().execute().body();
                Truth.assertThat(lista.size()).isEqualTo(5);
            }
            catch (IOException ioException){
                ioException.printStackTrace();
            }
        }


}