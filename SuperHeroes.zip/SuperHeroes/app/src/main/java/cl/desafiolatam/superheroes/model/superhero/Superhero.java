package cl.desafiolatam.superheroes.model.superhero;

import java.util.List;

public class Superhero{
	private List<SuperheroItem> superhero;

	public List<SuperheroItem> getSuperhero(){
		return superhero;
	}

	@Override
 	public String toString(){
		return 
			"Superhero{" + 
			"superhero = '" + superhero + '\'' + 
			"}";
		}
}