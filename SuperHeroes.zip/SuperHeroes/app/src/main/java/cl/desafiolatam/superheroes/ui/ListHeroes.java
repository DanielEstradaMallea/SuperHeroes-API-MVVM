package cl.desafiolatam.superheroes.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import cl.desafiolatam.superheroes.R;
import cl.desafiolatam.superheroes.adapter.SuperheroAdapter;
import cl.desafiolatam.superheroes.databinding.FragmentListHeroesBinding;
import cl.desafiolatam.superheroes.model.superhero.SuperheroItem;
import cl.desafiolatam.superheroes.viewmodel.SuperheroViewModel;


public class ListHeroes extends Fragment {


    private FragmentListHeroesBinding binding;
    private SuperheroViewModel viewModel;
    private SuperheroAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = FragmentListHeroesBinding.inflate(inflater, container, false);
        viewModel = new ViewModelProvider(getActivity()).get(SuperheroViewModel.class);
        // Inflate the layout for this fragment
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adapter = new SuperheroAdapter();
        GridLayoutManager manager = new GridLayoutManager(getContext(), 1);
        setHasOptionsMenu(true);
        binding.rvHeroList.setAdapter(adapter);
        binding.rvHeroList.setLayoutManager(manager);


        adapter.setListener(new SuperheroAdapter.MiOnClickListener() {

            @Override
            public void onClickListener(SuperheroItem hero) {

                viewModel.getHero(hero);
                Navigation.findNavController(getView()).navigate(R.id.action_listHeroes_to_detailsHero);
            }
        });


        viewModel.getHeroesList().observe(getViewLifecycleOwner(), hero -> {

            adapter.setLista(hero);


        });


    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {


        inflater = getActivity().getMenuInflater();
        inflater.inflate(R.menu.superhero_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searView = (SearchView) searchItem.getActionView();

        searView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                viewModel.callApiHeroes();


                viewModel.getHeroesList().observe(getViewLifecycleOwner(), hero -> {

                    adapter.setLista(hero);


                });


                return true;
            }
        });


    }


}
