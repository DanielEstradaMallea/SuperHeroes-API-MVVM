package cl.desafiolatam.superheroes.model.superhero;

public class Powerstats{
	private int strength;
	private int durability;
	private int combat;
	private int power;
	private int speed;
	private int intelligence;

	public int getStrength(){
		return strength;
	}

	public int getDurability(){
		return durability;
	}

	public int getCombat(){
		return combat;
	}

	public int getPower(){
		return power;
	}

	public int getSpeed(){
		return speed;
	}

	public int getIntelligence(){
		return intelligence;
	}

	@Override
 	public String toString(){
		return 
			"Powerstats{" + 
			"strength = '" + strength + '\'' + 
			",durability = '" + durability + '\'' + 
			",combat = '" + combat + '\'' + 
			",power = '" + power + '\'' + 
			",speed = '" + speed + '\'' + 
			",intelligence = '" + intelligence + '\'' + 
			"}";
		}
}
