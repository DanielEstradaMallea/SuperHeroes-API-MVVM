package cl.desafiolatam.superheroes.viewmodel;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import cl.desafiolatam.superheroes.client.RetrofitCliente;

import cl.desafiolatam.superheroes.model.superhero.SuperheroItem;
import cl.desafiolatam.superheroes.service.SuperheroAPI;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SuperheroViewModel extends ViewModel {

    private SuperheroAPI service = RetrofitCliente.getInstance(RetrofitCliente.BASE_URL);
    private MutableLiveData<List<SuperheroItem>> heroesList = new MutableLiveData<List<SuperheroItem>>();
    private MutableLiveData<SuperheroItem> heroDetails = new MutableLiveData<>();

    public void callApiHeroes() {

        service.CallToHeroes().enqueue(new Callback<List<SuperheroItem>>() {
            @Override
            public void onResponse(Call<List<SuperheroItem>> call, Response<List<SuperheroItem>> response) {

                heroesList.postValue(response.body());
                }

            @Override
            public void onFailure(Call<List<SuperheroItem>> call, Throwable t) {
                Log.i("Call Heores", t.getMessage());
                call.cancel();

            }
        });
    }

    public void getHero(SuperheroItem hero) {
        heroDetails.setValue(hero);
    }

    public MutableLiveData<List<SuperheroItem>> getHeroesList() {
        return heroesList;
    }

    public MutableLiveData<SuperheroItem> getHeroDetails() {
        return heroDetails;
    }
}



