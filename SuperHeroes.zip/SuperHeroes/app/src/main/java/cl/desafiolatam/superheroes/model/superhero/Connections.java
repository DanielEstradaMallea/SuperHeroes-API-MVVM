package cl.desafiolatam.superheroes.model.superhero;

public class Connections{
	private String groupAffiliation;
	private String relatives;

	public String getGroupAffiliation(){
		return groupAffiliation;
	}

	public String getRelatives(){
		return relatives;
	}

	@Override
 	public String toString(){
		return 
			"Connections{" + 
			"groupAffiliation = '" + groupAffiliation + '\'' + 
			",relatives = '" + relatives + '\'' + 
			"}";
		}
}
