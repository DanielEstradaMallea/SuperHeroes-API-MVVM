package cl.desafiolatam.superheroes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import cl.desafiolatam.superheroes.adapter.SuperheroAdapter;
import cl.desafiolatam.superheroes.databinding.ActivityMainBinding;
import cl.desafiolatam.superheroes.viewmodel.SuperheroViewModel;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private SuperheroViewModel viewModel;
    private SuperheroAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        viewModel = new ViewModelProvider(this).get(SuperheroViewModel.class);
        viewModel.callApiHeroes();

    }
}