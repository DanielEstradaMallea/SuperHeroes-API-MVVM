package cl.desafiolatam.superheroes.model.superhero;

public class Work{
	private String occupation;
	private String base;

	public String getOccupation(){
		return occupation;
	}

	public String getBase(){
		return base;
	}

	@Override
 	public String toString(){
		return 
			"Work{" + 
			"occupation = '" + occupation + '\'' + 
			",base = '" + base + '\'' + 
			"}";
		}
}
