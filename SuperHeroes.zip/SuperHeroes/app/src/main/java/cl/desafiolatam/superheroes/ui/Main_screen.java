package cl.desafiolatam.superheroes.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;

import cl.desafiolatam.superheroes.R;
import cl.desafiolatam.superheroes.databinding.FragmentMainScreenBinding;


public class Main_screen extends Fragment {

    private FragmentMainScreenBinding binding;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding=FragmentMainScreenBinding.inflate(inflater, container, false);
        Glide.with(getContext()).load(R.drawable.loop).into(binding.imgLoop);
        // Inflate the layout for this fragment
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        binding.button.setOnClickListener(v -> {

            Navigation.findNavController(getView()).navigate(R.id.action_main_screen_to_listHeroes);
        });

    }
}