package cl.desafiolatam.superheroes.ui;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import android.text.style.EasyEditSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.charts.RadarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.data.RadarData;
import com.github.mikephil.charting.data.RadarDataSet;
import com.github.mikephil.charting.data.RadarEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import cl.desafiolatam.superheroes.R;
import cl.desafiolatam.superheroes.databinding.FragmentDetailsHeroBinding;
import cl.desafiolatam.superheroes.model.superhero.SuperheroItem;
import cl.desafiolatam.superheroes.viewmodel.SuperheroViewModel;


public class DetailsHero extends Fragment {


    private FragmentDetailsHeroBinding binding;
    private SuperheroViewModel viewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentDetailsHeroBinding.inflate(inflater, container, false);


        viewModel = new ViewModelProvider(getActivity()).get(SuperheroViewModel.class);

        viewModel.getHeroDetails().observe(getViewLifecycleOwner(), superheroItem -> {
            binding.setHero(superheroItem);


            Picasso.get().load(superheroItem.getImages().getMd()).into(binding.detalleAvatar);
            inflateChart(superheroItem);
            setupPieChart();

        });

        binding.btnVolver.setOnClickListener(v -> {
            viewModel.callApiHeroes();
            Navigation.findNavController(getView()).navigate(R.id.action_detailsHero_to_listHeroes);
        });


        // Inflate the layout for this fragment
        return binding.getRoot();
    }

    private void inflateChart(SuperheroItem hero) {

        ArrayList<PieEntry> entries = new ArrayList<>();

        entries.add(new PieEntry(hero.getPowerstats().getPower(), getString(R.string.power)));
        entries.add(new PieEntry(hero.getPowerstats().getCombat(), getString(R.string.combat)));
        entries.add(new PieEntry(hero.getPowerstats().getDurability(), getString(R.string.durabilidad)));
        entries.add(new PieEntry(hero.getPowerstats().getIntelligence(), getString(R.string.inteligencia)));
        entries.add(new PieEntry(hero.getPowerstats().getSpeed(), getString(R.string.velocidad)));
        entries.add(new PieEntry(hero.getPowerstats().getStrength(), getString(R.string.fuerza)));

        ArrayList<Integer> colors = new ArrayList<>();
        for (int color : ColorTemplate.MATERIAL_COLORS) {
            colors.add(color);
        }

        for (int color : ColorTemplate.JOYFUL_COLORS) {
            colors.add(color);
        }

        PieDataSet dataSet = new PieDataSet(entries, "Stats");
        dataSet.setColors(colors);

        PieData data = new PieData(dataSet);
        data.setDrawValues(true);
        data.setValueFormatter(new PercentFormatter(binding.chart));
        data.setValueTextSize(16);
        data.setValueTextColor(Color.BLACK);

        binding.chart.setData(data);
        binding.chart.invalidate();
        binding.chart.animateY(1500, Easing.EaseInOutQuad);
    }

    private void setupPieChart() {
        binding.chart.setDrawHoleEnabled(false);
        binding.chart.setDrawSlicesUnderHole(true);
        binding.chart.setUsePercentValues(false);
        binding.chart.setEntryLabelTextSize(12);
        binding.chart.setEntryLabelColor(Color.BLACK);
        binding.chart.setDrawCenterText(false);
        binding.chart.setCenterTextSize(16);
        binding.chart.getDescription().setEnabled(false);
        Legend l = binding.chart.getLegend();
        l.setEnabled(false);


    }


}

