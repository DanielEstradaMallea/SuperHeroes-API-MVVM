package cl.desafiolatam.superheroes.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.shape.RoundedCornerTreatment;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import cl.desafiolatam.superheroes.R;
import cl.desafiolatam.superheroes.databinding.ItemLayoutBinding;
import cl.desafiolatam.superheroes.model.superhero.SuperheroItem;

public class SuperheroAdapter extends RecyclerView.Adapter<SuperheroAdapter.CustomViewHolder> implements Filterable   {

    private List<SuperheroItem> lista = new ArrayList<>();
    private List<SuperheroItem> listaOriginal = new ArrayList<>();
   // private List<SuperheroItem> listaOriginal2 = new ArrayList<>();


    private MiOnClickListener listener;

    public void setLista(List<SuperheroItem> lista) {
        this.lista = lista;
        listaOriginal= new ArrayList<>(lista);
      //  listaOriginal2= new ArrayList<>(listaOriginal);


    }

    public void setListener(MiOnClickListener listener) {
        this.listener = listener;
    }


    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {

        holder.BindData(lista.get(position));
    }




    @Override
    public int getItemCount() {
        return lista.size();
    }

    @Override
    public Filter getFilter() {
        return listFilter;
    }

    private Filter listFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {


            List<SuperheroItem> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(listaOriginal);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (SuperheroItem item : listaOriginal) {
                    if (item.getName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }

            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

            lista.clear();
            lista.addAll((List)results.values);
            notifyDataSetChanged();

          // lista.addAll(listaOriginal);
          // notifyDataSetChanged();

        }
    };

    public interface MiOnClickListener {
        void onClickListener(SuperheroItem hero);
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        private ItemLayoutBinding binding;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemLayoutBinding.bind(itemView);
        }

        public void BindData(SuperheroItem hero) {


            Picasso.get().load(hero.getImages().getMd()).into(binding.itemAvatar);
            binding.setHero(hero);

            itemView.setOnClickListener(v -> {
                listener.onClickListener(hero);

            });

        }
    }
}
