package cl.desafiolatam.superheroes.model.superhero;

public class Images{
	private String md;
	private String sm;
	private String xs;
	private String lg;

	public String getMd(){
		return md;
	}

	public String getSm(){
		return sm;
	}

	public String getXs(){
		return xs;
	}

	public String getLg(){
		return lg;
	}

	@Override
 	public String toString(){
		return 
			"Images{" + 
			"md = '" + md + '\'' + 
			",sm = '" + sm + '\'' + 
			",xs = '" + xs + '\'' + 
			",lg = '" + lg + '\'' + 
			"}";
		}
}
