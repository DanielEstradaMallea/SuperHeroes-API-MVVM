package cl.desafiolatam.superheroes.service;

import java.util.List;


import cl.desafiolatam.superheroes.model.superhero.Superhero;
import cl.desafiolatam.superheroes.model.superhero.SuperheroItem;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface SuperheroAPI {

    @GET("all.json")
    public Call<List<SuperheroItem>> CallToHeroes();


}
