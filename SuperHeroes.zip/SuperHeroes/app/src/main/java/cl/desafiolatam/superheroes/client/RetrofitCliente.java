package cl.desafiolatam.superheroes.client;

import cl.desafiolatam.superheroes.service.SuperheroAPI;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitCliente {


    public static final String BASE_URL = "https://akabab.github.io/superhero-api/api/";
    private static Retrofit instance;


    private RetrofitCliente() {
    }

    public static SuperheroAPI getInstance(String url) {
        if (instance == null) {
            instance = new Retrofit.Builder()
                    .baseUrl(url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return instance.create(SuperheroAPI.class);
    }


}
